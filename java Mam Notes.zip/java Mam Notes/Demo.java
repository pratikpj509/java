import java.util.Scanner;
class Demo{
 public static void main(String []args){
 	Scanner sc=new Scanner(System.in);
 	//-int n=sc.nextInt();
 	//System.out.println("int"+n);
 	//float f=sc.nextFloat();
	//System.out.println("float"+f);
 	//String s=sc.next();
	//System.out.println("string"+s);
        //sc.nextLine();
        String s1=sc.nextLine();
	System.out.println("string1"+s1);
   
}
}