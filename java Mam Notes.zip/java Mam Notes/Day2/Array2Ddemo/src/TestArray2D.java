
public class TestArray2D {

	public static void main(String[] args) {
		int[][] arr=new int[3][4];
		Array2DService.acceptData(arr);
		Array2DService.displayData(arr);

	}

}
